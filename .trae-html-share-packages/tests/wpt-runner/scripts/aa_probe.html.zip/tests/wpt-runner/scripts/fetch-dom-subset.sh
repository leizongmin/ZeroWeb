#!/usr/bin/env bash
# Fetch a pinned subset of the upstream WPT dom/ tests (testharness style)
# used by the JS/DOM nativization goal (docs/goal/archive/js-dom.md, M4 / DC-3).
#
# Strategy: first batch = main-thread .html cases of dom/nodes/ (the core
# Node/Element/Document surface — directly exercises native DOM bindings vs
# polyfill). Subdirectories (events/, collections/, lists/, ranges/,
# traversal/) are appended per M4 slices as the baseline grows.
#
# 与 fetch-canvas-subset.sh 同构（同 WPT_REV pin + GitHub API 列目录 + raw 拉单文件）。
# wpt-data 整体 gitignored，用例按需 fetch、不入库。

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../../.." && pwd)"
WPT_DATA="${REPO_ROOT}/tests/wpt-runner/wpt-data"
WPT_REV="315976933870b34d6ea30e3f6643403edae678ba"
RAW_ROOT="https://raw.githubusercontent.com/web-platform-tests/wpt/${WPT_REV}"
API_ROOT="https://api.github.com/repos/web-platform-tests/wpt/contents"

# 第一批：dom/nodes/ 核心 Node/Element/Document 主线程 .html 用例。
# R21：追加 dom/events/（81 .html——Event-dispatch 系列 / EventTarget / EventListener，直接测试
# addEventListener/dispatchEvent/事件传播，是 JS↔DOM 事件桥核心能力面，高 ROI 缺口暴露）。
# 后续 M4 切片按需追加 "dom/collections" / "dom/lists" / "dom/ranges" / "dom/traversal"。
SUBDIRS=(
  "dom/nodes"
  "dom/events"
  "dom/collections"
  "dom/traversal"
  "dom/ranges"
  "dom/abort"
  "dom/lists"
  "dom"
)

fetch_raw() {
  local relative="$1"
  local target="${WPT_DATA}/${relative}"
  if [[ -s "${target}" && "${FORCE:-0}" != "1" ]]; then
    return 0
  fi
  mkdir -p "$(dirname "${target}")"
  local temporary="${target}.tmp"
  curl --fail --location --silent --show-error --retry 3 \
    --connect-timeout 8 --max-time 30 \
    "${RAW_ROOT}/${relative}" -o "${temporary}"
  # R176：合法空文件放行——Document-createElement-namespace-tests 的 empty.* 是
  # 设计为 0 字节的测试形态（空文档）；`test -s` 把 curl 成功的空响应当失败，
  # .tmp 残留使该 fixture 永远拉不到。curl --fail 已保证非 2xx 报错，这里只需
  # 确认文件存在。
  test -e "${temporary}"
  mv "${temporary}" "${target}"
}

fetch_dir_html() {
  local dir="$1"
  local local_dir="${WPT_DATA}/${dir}"
  # 幂等快路径：WPT_REV 固定 → 目录文件集稳定。若目录已含 .html 用例（此前已 fetch），且
  # 未设 FORCE=1，则跳过 GitHub Contents API 列目录步骤（避免无谓的未认证 API 调用触发
  # GitHub 60/h 速率限制 → 403 阻断 `make testharness-dom`）。缺文件时仍逐文件 fetch_raw（其
  # 自身 `-s` 跳过已存在）；FORCE=1 强制重列目录拉最新文件集。
  if [[ "${FORCE:-0}" != "1" && -d "${local_dir}" ]]; then
    if compgen -G "${local_dir}/*.html" > /dev/null; then
      echo "  ${dir}: 已含 .html 用例，跳过 API 列目录（FORCE=1 可强制重列）"
      return 0
    fi
  fi
  local names
  names=$(curl --fail --location --silent --show-error --retry 3 --connect-timeout 8 --max-time 30 \
    "${API_ROOT}/${dir}" | grep -o '"name": "[^"]*"')
  while IFS= read -r line; do
    local name="${line#\"name\": \"}"
    name="${name%\"}"
    # 拉主线程 .html + .js 依赖（用例常引用同目录 .js 测试体，如 Document-createElementNS.js）。
    # 排除 .worker.js / .any.js 变体（需 dedicated worker / 不同 harness）。
    # R176：追加 .xml/.xhtml/.svg——Document-createElement-namespace-tests 子目录的
    # iframe fixture 是四扩展全集（fetch_dir_html 复用于该子目录时需要）。
    case "${name}" in
      *.html | *.js | *.xml | *.xhtml | *.svg) fetch_raw "${dir}/${name}" ;;
    esac
  done <<< "${names}"
}

# testharness.js / testharnessreport.js 为所有 dom 用例共享（canvas fetch 已拉 testharness.js 则跳过）。
# testharnessreport.js：runner 内联替换为空，但仍需文件存在（prepare_harness_html 替换 src）。
fetch_raw "resources/testharness.js"
fetch_raw "resources/testharnessreport.js"
# dom 根共享 JS（dom/nodes 用例引用 ../constants.js / ../common.js）。
fetch_raw "dom/constants.js"
fetch_raw "dom/common.js"
# dom/events 共享 JS（js-dom R113：webkit-animation/transition 四用例引用
# resources/prefixed-animation-event-tests.js——缺文件时 runner 报 script fetch failed）。
fetch_raw "dom/events/resources/prefixed-animation-event-tests.js"
# js-dom R198：dom/nodes/support/ 共享 JS（NodeList-static-length-getter-tampered-{1..3,-indexOf-{1..3}}
# 六用例引用 support/NodeList-static-length-tampered.js——fetch_dir_html 只列子目录顶层 .html/.js，
# 不递归 support/；缺文件时六用例 "script fetch failed" 整簇 fail）。
fetch_raw "dom/nodes/support/NodeList-static-length-tampered.js"
# dom 根共享 /common/ 静态文档（js-dom R115：Document-createElement/case/createElementNS 等
# ~750 subtest 经 <iframe src="/common/dummy.xml|.xhtml"> 取 XML/XHTML 文档——缺文件时
# contentDocument 恒 undefined）。dummy.xml/xhtml 是最小静态文档，R115 iframe
# contentDocument 切片消费。
fetch_raw "common/dummy.xml"
fetch_raw "common/dummy.xhtml"

# js-dom R176：Document-createElement-namespace 的 iframe fixture 子目录（40 subtest 经
# `<iframe src="Document-createElement-namespace-tests/<name>.<ext>">` 取 4 扩展 × 10 形态
# 的外部文档——fetch_dir_html 只拉 .html/.js 且不递归子目录，缺文件时 contentDocument
# 恒 null → "Cannot read properties of null (reading 'contentType')" 整簇 fail）。全 41
# 文件（4 扩展 × 10 形态 + generate.py）逐个拉。
fetch_dir_html "dom/nodes/Document-createElement-namespace-tests"

for dir in "${SUBDIRS[@]}"; do
  fetch_dir_html "${dir}"
done

echo "DOM testharness subset ready (${#SUBDIRS[@]} dirs, WPT ${WPT_REV})"
