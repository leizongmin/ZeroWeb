#!/usr/bin/env bash
# Restore a pinned Service Worker testharness corpus.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../../.." && pwd)"
WPT_REV="04067ce9c7c2165e71ad7d0dde10a4c5cb394a83"
ASSET_MANIFEST="${WPT_ASSET_MANIFEST:-${REPO_ROOT}/docs/goal/archive/service-workers/evidence/2026-08-19-m1-tier-a-assets.tsv}"
DATA_ROOT="${WPT_SERVICE_WORKER_DATA:-${REPO_ROOT}/tests/wpt-runner/wpt-data/.service-workers-tier-a-root}"
if [[ -n "${WPT_REMOTE_BASE:-}" ]]; then
  REMOTE_BASE="${WPT_REMOTE_BASE}"
elif [[ -n "${WPT_REMOTE_ROOT:-}" ]]; then
  REMOTE_BASE="${WPT_REMOTE_ROOT%/${WPT_REV}}/"
else
  REMOTE_BASE="https://raw.githubusercontent.com/web-platform-tests/wpt/"
fi
if [[ -n "${WPT_FALLBACK_BASE:-}" ]]; then
  FALLBACK_BASE="${WPT_FALLBACK_BASE}"
elif [[ -n "${WPT_FALLBACK_ROOT:-}" ]]; then
  FALLBACK_BASE="${WPT_FALLBACK_ROOT%@${WPT_REV}}@"
else
  FALLBACK_BASE="https://cdn.jsdelivr.net/gh/web-platform-tests/wpt@"
fi
CORPUS_LABEL="${WPT_CORPUS_LABEL:-Service Worker Tier A}"
EXPECTED_ASSET_COUNT="${WPT_EXPECTED_ASSET_COUNT:-19}"
MODE="restore"

if [[ "${1:-}" == "--verify-only" ]]; then
  MODE="verify"
  shift
fi
if [[ "$#" -ne 0 ]]; then
  echo "Usage: $0 [--verify-only]" >&2
  exit 2
fi
if [[ ! "${EXPECTED_ASSET_COUNT}" =~ ^[1-9][0-9]*$ ]]; then
  echo "Invalid expected Service Worker WPT asset count: ${EXPECTED_ASSET_COUNT}" >&2
  exit 2
fi

blob_sha() {
  git hash-object -- "$1"
}

validate_entry() {
  local relative="$1"
  local expected_bytes="$2"
  local expected_sha="$3"
  local source_revision="$4"

  case "${relative}" in
    "" | /* | ../* | */../* | */..) return 1 ;;
  esac
  [[ "${expected_bytes}" =~ ^[0-9]+$ ]]
  [[ "${expected_sha}" =~ ^[0-9a-f]{40}$ ]]
  [[ "${source_revision}" =~ ^[0-9a-f]{40}$ ]]
}

matches_manifest() {
  local file="$1"
  local expected_bytes="$2"
  local expected_sha="$3"

  [[ -f "${file}" ]] || return 1
  [[ "$(wc -c < "${file}")" -eq "${expected_bytes}" ]] || return 1
  [[ "$(blob_sha "${file}")" == "${expected_sha}" ]]
}

fetch_remote() {
  local base="$1"
  local revision="$2"
  local relative="$3"
  local output="$4"
  local separator="/"

  case "${base}" in
    */ | *@) separator="" ;;
  esac

  curl --fail --location --silent --show-error --retry 2 --retry-all-errors \
    --continue-at - \
    --connect-timeout 10 --max-time 30 \
    "${base}${separator}${revision}/${relative}" -o "${output}"
}

restore_asset() {
  local relative="$1"
  local expected_bytes="$2"
  local expected_sha="$3"
  local source_revision="$4"
  local target="${DATA_ROOT}/${relative}"
  local temporary="${target}.tmp"

  if matches_manifest "${target}" "${expected_bytes}" "${expected_sha}"; then
    return 0
  fi

  mkdir -p "$(dirname "${target}")"
  if [[ -n "${WPT_SOURCE:-}" ]]; then
    if [[ -f "${WPT_SOURCE}/${relative}" ]]; then
      cp "${WPT_SOURCE}/${relative}" "${temporary}"
    fi
    if matches_manifest "${temporary}" "${expected_bytes}" "${expected_sha}"; then
      mv "${temporary}" "${target}"
      return 0
    fi
    rm -f "${temporary}"
  fi

  if ! fetch_remote "${REMOTE_BASE}" "${source_revision}" "${relative}" "${temporary}"; then
    if ! fetch_remote "${FALLBACK_BASE}" "${source_revision}" "${relative}" "${temporary}"; then
      echo "${CORPUS_LABEL} download incomplete; resumable file kept: ${relative}" >&2
      return 1
    fi
  fi

  if ! matches_manifest "${temporary}" "${expected_bytes}" "${expected_sha}"; then
    echo "${CORPUS_LABEL} asset failed manifest verification: ${relative}" >&2
    rm -f "${temporary}"
    return 1
  fi
  mv "${temporary}" "${target}"
}

[[ -f "${ASSET_MANIFEST}" ]] || {
  echo "${CORPUS_LABEL} asset manifest not found: ${ASSET_MANIFEST}" >&2
  exit 1
}

count=0
while IFS=$'\t' read -r relative _manifest_type _roles _referenced_by expected_bytes _templated expected_sha source_revision; do
  if [[ "${relative}" == "path" ]]; then
    continue
  fi
  source_revision="${source_revision:-${WPT_REV}}"
  if ! validate_entry "${relative}" "${expected_bytes}" "${expected_sha}" "${source_revision}"; then
    echo "Invalid ${CORPUS_LABEL} manifest entry: ${relative}" >&2
    exit 1
  fi
  if [[ "${MODE}" == "verify" ]]; then
    if ! matches_manifest "${DATA_ROOT}/${relative}" "${expected_bytes}" "${expected_sha}"; then
      echo "${CORPUS_LABEL} asset does not match manifest: ${relative}" >&2
      exit 1
    fi
  else
    restore_asset "${relative}" "${expected_bytes}" "${expected_sha}" "${source_revision}"
  fi
  count=$((count + 1))
done < "${ASSET_MANIFEST}"

if [[ "${count}" -ne "${EXPECTED_ASSET_COUNT}" ]]; then
  echo "${CORPUS_LABEL} asset count mismatch: expected ${EXPECTED_ASSET_COUNT}, found ${count}" >&2
  exit 1
fi

echo "${CORPUS_LABEL} corpus ${MODE} complete (${count} assets, default WPT ${WPT_REV})"
